export async function api(path, opts = {}) {
  const res = await fetch(path, {
    credentials: "include",
    ...opts,
    headers: {
      "content-type": "application/json",
      ...(opts.headers || {})
    }
  });

  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }

  if (!res.ok) {
    const msg = data?.error?.message || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

export function money(n) {
  const v = Number(n || 0);
  return `₹${v.toFixed(2)}`;
}

export function $(sel, root = document) {
  return root.querySelector(sel);
}

export function $$(sel, root = document) {
  return [...root.querySelectorAll(sel)];
}

export function toast(title, message) {
  const el = $("#toast");
  if (!el) return alert(`${title}\n\n${message}`);
  $(".t", el).textContent = title;
  $(".m", el).textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 3500);
}

export async function requireAuth() {
  try {
    const me = await api("/api/auth/me");
    return me.user;
  } catch {
    window.location.href = "/login.html";
    return null;
  }
}

export function todayIso() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

