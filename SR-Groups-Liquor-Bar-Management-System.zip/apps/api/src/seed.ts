import type { Db } from "./db";

export async function seedIfNeeded(
  db: Db,
  opts: {
    adminUsername: string;
    adminPassword: string;
    rotatePassword?: boolean;
    shopUsers?: { shopName: string; username: string; password: string; rotatePassword?: boolean }[];
  }
) {
  const existing = db
    .query("SELECT id, password_hash FROM users WHERE username = ?")
    .get(opts.adminUsername) as { id: number; password_hash: string } | null;

  if (!existing) {
    const passwordHash = await Bun.password.hash(opts.adminPassword);
    db.query("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'OWNER')").run(
      opts.adminUsername,
      passwordHash
    );
    // eslint-disable-next-line no-console
    console.log(
      `[seed] Created OWNER user '${opts.adminUsername}'. Change ADMIN_PASSWORD after first login.`
    );
  } else if (opts.rotatePassword) {
    const ok = await Bun.password.verify(opts.adminPassword, existing.password_hash);
    if (!ok) {
      const passwordHash = await Bun.password.hash(opts.adminPassword);
      db.query("UPDATE users SET password_hash = ? WHERE id = ?").run(passwordHash, existing.id);
      // eslint-disable-next-line no-console
      console.log(`[seed] Updated password for '${opts.adminUsername}' from ADMIN_PASSWORD.`);
    }
  }

  const shops = ["Ravi Liquor Shop", "Aishwarya Bar"];
  const shopAddresses: Record<string, string> = {
    "Ravi Liquor Shop":
      "SR complex no: 03,S.R(Sirige Rudramuniyappa) Ring Road,Rahim Nagara,challakere-577522",
    "Aishwarya Bar":
      "SH 48,near Government degree College ground, chitradurga Road, Challakere-577522"
  };

  for (const name of shops) {
    const address = shopAddresses[name] ?? null;
    db.query("INSERT OR IGNORE INTO shops (name, address) VALUES (?, ?)").run(name, address);
    if (address) {
      db.query(
        "UPDATE shops SET address = ? WHERE name = ? AND (address IS NULL OR TRIM(address) = '')"
      ).run(address, name);
    }
  }

  const shopRows = db.query("SELECT id FROM shops").all() as { id: number }[];
  for (const { id } of shopRows) {
    db.query("INSERT OR IGNORE INTO bill_counters (shop_id, next_bill_no) VALUES (?, 1)").run(
      id
    );
  }

  const shopIdByName = new Map(
    (db.query("SELECT id, name FROM shops").all() as { id: number; name: string }[]).map((s) => [
      s.name,
      s.id
    ])
  );

  for (const su of opts.shopUsers ?? []) {
    const shopId = shopIdByName.get(su.shopName);
    if (!shopId) continue;
    const existingShopUser = db
      .query("SELECT id, password_hash FROM users WHERE username = ?")
      .get(su.username) as { id: number; password_hash: string } | null;

    if (!existingShopUser) {
      const passwordHash = await Bun.password.hash(su.password);
      db.query("INSERT INTO users (username, password_hash, role, shop_id) VALUES (?, ?, 'STAFF', ?)")
        .run(su.username, passwordHash, shopId);
      // eslint-disable-next-line no-console
      console.log(`[seed] Created STAFF user '${su.username}' for '${su.shopName}'.`);
    } else if (su.rotatePassword) {
      const ok = await Bun.password.verify(su.password, existingShopUser.password_hash);
      if (!ok) {
        const passwordHash = await Bun.password.hash(su.password);
        db.query("UPDATE users SET password_hash = ?, shop_id = ?, role = 'STAFF' WHERE id = ?").run(
          passwordHash,
          shopId,
          existingShopUser.id
        );
        // eslint-disable-next-line no-console
        console.log(`[seed] Updated password for '${su.username}' from env.`);
      } else {
        db.query("UPDATE users SET shop_id = ?, role = 'STAFF' WHERE id = ?").run(
          shopId,
          existingShopUser.id
        );
      }
    } else {
      db.query("UPDATE users SET shop_id = ?, role = 'STAFF' WHERE id = ?").run(
        shopId,
        existingShopUser.id
      );
    }
  }
}
