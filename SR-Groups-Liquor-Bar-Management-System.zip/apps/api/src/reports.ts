import type { Db } from "./db";
import { dateIso } from "./db";
import { env, envBool, envOptional } from "./env";
import { randomToken } from "./crypto";
import { normalizePhoneNumbers, sendSms } from "./sms";
import { pdfFromLines } from "./pdf";
import { mkdir } from "node:fs/promises";

function moneyRs(n: number) {
  return `Rs ${n.toFixed(2)}`;
}

function asNumber(v: any) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function categoryLabel(code: any) {
  const c = String(code ?? "").toUpperCase();
  if (c === "WHISKEY") return "Whiskey";
  if (c === "BRANDY") return "Brandy";
  if (c === "RUM") return "Rum";
  if (c === "BEER") return "Beer";
  if (c === "GIN") return "Gin";
  if (c === "WINE") return "Wine";
  if (c === "CARBONATED_WINE") return "Carbonated Wine";
  if (c === "OTHERS") return "Others";
  return c ? String(code) : "Others";
}

export async function generateDailyStockSalesReport(
  db: Db,
  opts: { date?: string; shopId?: number | null }
) {
  const reportDate = opts.date ?? dateIso(new Date());
  const shops = opts.shopId
    ? (db
        .query("SELECT id, name FROM shops WHERE id = ?")
        .all(opts.shopId) as { id: number; name: string }[])
    : (db.query("SELECT id, name FROM shops ORDER BY id").all() as {
        id: number;
        name: string;
      }[]);

  const lines: { text: string; bold?: boolean; size?: number }[] = [];
  lines.push({ text: `Report Date: ${reportDate}`, bold: true });
  lines.push({ text: "" });

  for (const shop of shops) {
    lines.push({ text: `Shop: ${shop.name}`, bold: true, size: 13 });

    const sales = db
      .query(
        `SELECT
          COALESCE(SUM(total), 0) as sales_total
        FROM bills
        WHERE shop_id = ? AND date(created_at) = ?`
      )
      .get(shop.id, reportDate) as any;

    const salesTotal = asNumber(sales.sales_total);

    lines.push({ text: `Sales (Daily):   ${moneyRs(salesTotal)}` });
    lines.push({ text: "" });

    lines.push({ text: "Incoming Stock (Daily IN):", bold: true });
    const incoming = db
      .query(
        `SELECT st.created_at, st.qty, st.invoice_no, st.permit_no, st.vehicle_no, st.cases, st.bottles, st.source,
                p.name as product_name, p.size as size
         FROM stock_transactions st
         JOIN products p ON p.id = st.product_id
         WHERE st.shop_id = ? AND st.type = 'IN' AND COALESCE(st.doc_date, date(st.created_at)) = ?
         ORDER BY st.created_at DESC
         LIMIT 150`
      )
      .all(shop.id, reportDate) as any[];

    if (incoming.length === 0) {
      lines.push({ text: "  (No incoming stock entries)" });
    } else {
      lines.push({
        text: "  TIME  PRODUCT/SIZE              QTY   CASE/BOT  INVNO      PERMIT     VEHICLE",
        bold: true
      });
      for (const row of incoming) {
        const createdAt = String(row.created_at ?? "");
        const time = createdAt.length >= 16 ? createdAt.slice(11, 16) : "-----";
        const productWithSize = `${String(row.product_name ?? "")} ${String(row.size ?? "")}`
          .trim()
          .slice(0, 22)
          .padEnd(22, " ");
        const qty = String(asNumber(row.qty).toFixed(2)).padStart(7, " ");
        const cbRaw =
          row.cases !== null || row.bottles !== null
            ? `${Number(row.cases ?? 0)}C/${Number(row.bottles ?? 0)}B`
            : "";
        const cb = String(cbRaw).slice(0, 9).padEnd(9, " ");
        const inv = String(row.invoice_no ?? "").slice(0, 9).padEnd(9, " ");
        const permit = String(row.permit_no ?? "").slice(0, 9).padEnd(9, " ");
        const veh = String(row.vehicle_no ?? "").slice(0, 9).padEnd(9, " ");
        lines.push({ text: `  ${time} ${productWithSize} ${qty} ${cb} ${inv} ${permit} ${veh}` });
      }
      if (incoming.length === 150) lines.push({ text: "  ... (more entries not shown)" });
    }

    lines.push({ text: "" });

    lines.push({ text: "Stock (Current Qty):", bold: true });
	
	    const products = db
	      .query(
        `SELECT name, category, size, current_qty, min_qty
         FROM products
         WHERE shop_id = ?
         ORDER BY category ASC, (current_qty < min_qty) DESC, name ASC`
      )
      .all(shop.id) as any[];

    if (products.length === 0) {
      lines.push({ text: "  (No products yet)" });
    } else {
      let lastCat = "";
      for (const p of products.slice(0, 160)) {
        const cat = categoryLabel(p.category ?? "OTHERS");
        if (cat !== lastCat) {
          lines.push({ text: `  CATEGORY: ${cat}`, bold: true });
          lines.push({ text: "    SIZE     NAME                           QTY", bold: true });
          lastCat = cat;
        }
        const size = String(p.size ?? "").slice(0, 8).padEnd(8, " ");
        const name = String(p.name ?? "").slice(0, 30).padEnd(30, " ");
        const qty = String(asNumber(p.current_qty).toFixed(2)).padStart(7, " ");
        lines.push({ text: `    ${size} ${name} ${qty}` });
      }
      if (products.length > 160) lines.push({ text: `  ... (${products.length - 160} more)` });
    }

    lines.push({ text: "" });
    lines.push({ text: "------------------------------------------------------------" });
    lines.push({ text: "" });
  }

  const fileName = `${reportDate.replace(/-/g, "")}-${opts.shopId ? `shop${opts.shopId}-` : ""}${randomToken(10)}.pdf`;
  const reportsDir = env("REPORTS_DIR", "./apps/api/reports");
  await mkdir(reportsDir, { recursive: true });

  const bytes = pdfFromLines("SR Groups - Daily Stock & Sales Report", lines);
  await Bun.write(`${reportsDir}/${fileName}`, bytes);

  db.query(
    "INSERT INTO reports (report_date, shop_id, kind, file_name) VALUES (?, ?, 'DAILY_STOCK_SALES', ?)"
  ).run(reportDate, opts.shopId ?? null, fileName);

  return { fileName, reportDate, shopId: opts.shopId ?? null };
}

export async function sendDailyReportSmsLink(opts: {
  fileName: string;
  reportDate: string;
  shopId?: number | null;
}) {
  const baseUrl = env("PUBLIC_BASE_URL", "http://localhost:3000").replace(/\/+$/, "");
  const reportsPublic = envBool("REPORTS_PUBLIC", true);
  const link = reportsPublic ? `${baseUrl}/reports/${opts.fileName}` : `${baseUrl}/dashboard.html`;

  const defaultCc = envOptional("PHONE_DEFAULT_COUNTRY_CODE") ?? "+91";
  const toList = normalizePhoneNumbers(envOptional("DAILY_REPORT_SMS_TO"), defaultCc);
  const body = `SR Groups report (${opts.reportDate}) ready. Download: ${link}`;

  for (const to of toList) {
    await sendSms(to, body);
  }
}

export function scheduleDailyReports(db: Db) {
  const time = envOptional("DAILY_REPORT_TIME") ?? "21:00";
  const [hh, mm] = time.split(":").map((x) => Number.parseInt(x, 10));
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) {
    // eslint-disable-next-line no-console
    console.log(`[reports] Invalid DAILY_REPORT_TIME='${time}', skipping scheduler.`);
    return;
  }

  const scheduleNext = () => {
    const now = new Date();
    const next = new Date(now);
    next.setHours(hh, mm, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    const ms = next.getTime() - now.getTime();

    setTimeout(async () => {
      try {
        const rep = await generateDailyStockSalesReport(db, { date: dateIso(new Date()) });
        await sendDailyReportSmsLink({ fileName: rep.fileName, reportDate: rep.reportDate });
        // eslint-disable-next-line no-console
        console.log(`[reports] Generated daily report ${rep.fileName}`);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log(`[reports] Daily report error:`, e);
      } finally {
        scheduleNext();
      }
    }, ms);

    // eslint-disable-next-line no-console
    console.log(`[reports] Next daily report scheduled at ${next.toString()}`);
  };

  scheduleNext();
}
